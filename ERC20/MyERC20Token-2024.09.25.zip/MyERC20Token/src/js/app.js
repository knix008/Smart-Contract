App = {
  web3Provider: null,
  contracts: {},

  init: function() {
    return App.initWeb3();
  },

  initWeb3: async function () {
    // Modern dapp browsers...
    if (window.ethereum) {
      App.web3Provider = window.ethereum;
      try {
        // Request account access
        //await window.ethereum.reqeustAccounts();

        const accounts = await window.ethereum.request({
          method: "eth_requestAccounts",
        });


      } catch (error) {
        // User denied account access...
        console.error("User denied account access");
      }
    }
    // Legacy dapp browsers...
    else if (window.web3) {
      App.web3Provider = window.web3.currentProvider;
    }
    // If no injected web3 instance is detected, fall back to Ganache
    else {
      App.web3Provider = new Web3.providers.HttpProvider(
        "http://localhost:7545"
      );
    }
    web3 = new Web3(App.web3Provider);
    return App.initContract();
  },

  initContract: function () {
    $.getJSON("MyERC20Token.json", function (data) {
      // Get the necessary contract artifact file and instantiate it with @truffle/contract
      var MyERC20TokenArtifact = data;
      App.contracts.MyERC20Token = TruffleContract(MyERC20TokenArtifact);

      // Set the provider for our contract
      App.contracts.MyERC20Token.setProvider(App.web3Provider);

      // Use our contract to retrieve and mark the adopted pets
      return App.getBalances();
    });
    return App.bindEvents();
  },

  bindEvents: function() {
    $(document).on('click', '#transferButton', App.handleTransfer);
  },

  handleTransfer: function(event) {
    event.preventDefault();

    var amount = parseInt($('#MTKTransferAmount').val());
    var toAddress = $('#MTKTransferAddress').val();
    console.log('Transfer ' + amount + ' MTK to ' + toAddress);

    var myERC20TokenInstance;
    web3.eth.getAccounts(function(error, accounts) {
      if (error) {
        console.log(error);
      }
      console.log('Account : ' + accounts[0]);

      var account = accounts[0];
      App.contracts.MyERC20Token.deployed().then(function(instance) {
        myERC20TokenInstance = instance;
        return myERC20TokenInstance.transfer(toAddress, amount, {from: account, gas: 100000});
      }).then(function(result) {
        alert('Transfer Successful!');
        return App.getBalances();
      }).catch(function(err) {
        console.log(err.message);
      });
    });
  },

  getBalances: function() {
    console.log('Getting balances...');

    var myERC20TokenInstance;

    web3.eth.getAccounts(function(error, accounts) {
      if (error) {
        console.log(error);
      }

      var account = accounts[0];

      App.contracts.MyERC20Token.deployed().then(function(instance) {
        myERC20TokenInstance = instance;

        return myERC20TokenInstance.balanceOf(account);
      }).then(function(result) {
        balance = result.c[0];

        $('#MTKBalance').text(balance);
      }).catch(function(err) {
        console.log(err.message);
      });
    });
  }

};

$(function() {
  $(window).load(function() {
    App.init();
  });
});
