var MyERC20Token = artifacts.require("./MyERC20Token.sol");

module.exports = (deployer, networks, accounts) => {
  deployer.then(async () => {
    try {
      const ownerAddress = accounts[0];
      await deployer.deploy(MyERC20Token);
    } catch (err) {
      console.log(('Failed to Deploy Contracts', err))
    }
  })

}