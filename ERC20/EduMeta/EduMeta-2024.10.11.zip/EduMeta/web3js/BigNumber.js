const {ethers} = require("ethers");

const bigNumber = BigInt('12345678901234567890');
console.log(bigNumber.toString()); // '12345678901234567890