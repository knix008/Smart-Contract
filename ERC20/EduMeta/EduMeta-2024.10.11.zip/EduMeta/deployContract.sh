#!/usr/bin/sh
npx hardhat run ./scripts/EduMetaToken.js --network kairos
